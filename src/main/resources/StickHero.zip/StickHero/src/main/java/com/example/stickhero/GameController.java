package com.example.stickhero;

import java.io.IOException;
import java.util.Objects;

import javafx.animation.ParallelTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.Random;


public class GameController {
    private Stage stage;

    @FXML
    private ImageView stick;

    @FXML
    private ImageView capo;
    @FXML
    private Rectangle pillar1;

    @FXML
    private Rectangle pillar2;

    @FXML
    private Rectangle pillar3;

    private Scene scene;
    private Parent root;

    boolean mousePressed;

    public void switchToScene1(ActionEvent event) throws IOException {
        switchScenes();
    }

    private void switchScenes() throws IOException{
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("gameOver.fxml")));
        stage = HelloApplication.getStage();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public int RandomWidth() {
        Random rand = new Random();
        final int MIN_SIZE = 50;
        final int MAX_SIZE = 120;

        int width = 0;
        while (width < MIN_SIZE)
            width = rand.nextInt(MAX_SIZE);

        return width;
    }
    public double Randomdistance(Rectangle pillarx) {
        Random rand = new Random();
        final double MIN_SIZE = pillarx.getWidth()+50;
        final double MAX_SIZE = pillarx.getWidth()+300;

        double width = 0;
        while (width < MIN_SIZE)
            width = rand.nextDouble(MAX_SIZE);

        return width;
    }

    public int pillarnum=0;
    public void elongateRod(MouseEvent event) throws IOException,InterruptedException{
        mousePressed=true;
        Thread t1 = new Thread(()->{
            while(mousePressed){
                System.out.println(stick.getLayoutY());
                stick.setFitHeight(stick.getFitHeight()+5);
                System.out.println(stick.getFitHeight());
                System.out.println(stick.getFitWidth());
                stick.setLayoutY(stick.getLayoutY()-5);
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }

            }

        });
        t1.start();
    }
    public void stopelongation(MouseEvent event){
        mousePressed=false;
        stick.setRotate(90);
        stick.setLayoutY(stick.getLayoutY() + stick.getFitHeight() / 2);
        stick.setLayoutX(stick.getLayoutX() + stick.getFitHeight() / 2);
        TranslateTransition capy= new TranslateTransition();
        capy.setNode(capo);
        capy.setDuration(Duration.millis(1000));
        capy.setByX(stick.getFitHeight());
        capy.play();
        capy.setOnFinished((event1)->{
            resetStick();
            if(isCapyOut()==-1){// dying state
                System.out.println("lmao ded XD");
                TranslateTransition capyGira=new TranslateTransition(Duration.millis(500),capo);
                capyGira.setByY(1000);
                capyGira.play();

                //change back to main menu
                capyGira.setOnFinished((event2)->{
                    try {
                        switchScenes();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
            else if(isCapyOut()==3) {

                double move = (-pillar3.getLayoutX()) + 15;
                TranslateTransition capoTransGender = new TranslateTransition(Duration.millis(1500), capo);
                TranslateTransition pillar1TransGender = new TranslateTransition(Duration.millis(1500), pillar1);
                TranslateTransition pillar2TransGender = new TranslateTransition(Duration.millis(1500), pillar2);
                TranslateTransition pillar3TransGender = new TranslateTransition(Duration.millis(1500), pillar3);
                capoTransGender.setByX(move);
                pillar1TransGender.setByX(move);
                pillar2TransGender.setByX(move);
                pillar3TransGender.setByX(move);
                ParallelTransition animate = new ParallelTransition(capoTransGender,pillar1TransGender,pillar2TransGender,pillar3TransGender);
                animate.play();

                animate.setOnFinished((event69)->{
                    capo.setLayoutX(capo.getLayoutX()+capo.getTranslateX());
                    capo.setTranslateX(0);
                    pillar1.setLayoutX(pillar1.getLayoutX()+pillar1.getTranslateX());
                    pillar1.setTranslateX(0);
                    pillar2.setLayoutX(pillar2.getLayoutX()+pillar2.getTranslateX());
                    pillar2.setTranslateX(0);
                    pillar3.setLayoutX(pillar3.getLayoutX()+pillar3.getTranslateX());
                    pillar3.setTranslateX(0);
                    stick.setLayoutX(capo.getLayoutX()+47);
                    pillar1.setLayoutX(pillar3.getLayoutX());
                    pillar1.setWidth(pillar3.getWidth());
                    pillar2.setLayoutX(pillar1.getLayoutX()+Randomdistance(pillar2));
                    pillar3.setLayoutX(pillar2.getLayoutX()+Randomdistance(pillar3));
                    pillar3.setWidth(RandomWidth());
                    pillar2.setWidth(RandomWidth());
                    pillarnum=3;
                });
            }

        });

    }

    private void resetStick(){
        capo.setLayoutX(capo.getLayoutX()+capo.getTranslateX());
        capo.setTranslateX(0);
        stick.setLayoutY(stick.getLayoutY() + stick.getFitHeight() / 2);
        stick.setLayoutX(stick.getLayoutX() + stick.getFitHeight() / 2);
        stick.setFitHeight(0.01);
        stick.setRotate(0);
    }

    private int isCapyOut(){
        // VERY, VERY IMPORTANT, MAKE A FUCKING ARRAYLIST OF THE PILLARSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

        double coord=capo.getLayoutX()+(capo.getFitWidth()/2);
        if((coord>pillar1.getLayoutX())&&(coord<(pillar1.getLayoutX()+pillar1.getWidth()))){
            pillarnum=1;
        }
        else if((coord>pillar2.getLayoutX())&&(coord<(pillar2.getLayoutX()+pillar2.getWidth()))){
            pillarnum+=2;
        }
        else if((coord>pillar3.getLayoutX())&&(coord<(pillar3.getLayoutX()+pillar3.getWidth()))){
            pillarnum=3;
        }
        else {pillarnum=-1;}
        return pillarnum;
    }

}
